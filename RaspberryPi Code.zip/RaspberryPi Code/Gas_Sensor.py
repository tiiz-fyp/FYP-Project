import RPi.GPIO as GPIO
import time

channel = 16
GPIO.setmode(GPIO.BCM)
GPIO.setup(channel,GPIO.IN)

def callback(channel):
        print("Oof, A Gas leak has been potentially detected. Are you at home?")

GPIO.add_event_detect(channel, GPIO.BOTH, bouncetime=300)
GPIO.add_event_callback(channel,callback)

#loop
while True:
        time.sleep(1)


