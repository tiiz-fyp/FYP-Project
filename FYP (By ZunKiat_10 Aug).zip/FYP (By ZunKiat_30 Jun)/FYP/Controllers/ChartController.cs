﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using FYP.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.IdentityModel.Tokens;

namespace FYP.Controllers
{
    public class ChartController : Controller
    {
        [Authorize(Roles = "member")]
        public IActionResult Summary()
        {
            PrepareData(1); 
            ViewData["Chart"] = "line";
            ViewData["Title"] = "Temperature";
            ViewData["ShowLegend"] = "false";
            return View("Summary");
        }

        private void PrepareData(int v)
        {
            double[] temperature = new double[] { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 };
            for (int i = 0; i < temperature.Length; i++)
            {
                Random tempnumber = new Random();
                temperature[i] = tempnumber.Next(300);
                ViewData["Temperature"] = temperature[i];
            }
      
            List<Temperature> list = DBUtl.GetList<Temperature>("SELECT * FROM Temperature");
            foreach (Temperature temp in list)
            {
                ViewData["Temperature"] = new[] { "24", "46", "45", "30", "45", "80", "70", "50", "15", "26", "38", "76" };
                ViewData["Labels"] = new[] { "January", "Feburary", "March", "April", "May", "June", "July", "Auguest", "September", "October", "November", "December" };
                ViewData["Data"] = temperature;

            }
        }

    }
}

