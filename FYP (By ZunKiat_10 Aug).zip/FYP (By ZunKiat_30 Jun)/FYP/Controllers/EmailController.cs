﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Mail;
using System.Security.Claims;
using System.Threading.Tasks;
using FYP.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace FYP.Controllers
{
    public class EmailController : Controller
    {

        public IActionResult EmailSend()
        {
            return View("EmailSend");
        }

        [HttpPost]
        public IActionResult EmailSend(SysUser usr)
        {
            if (!ModelState.IsValid)
            {
                ViewData["Message"] = "Invalid Input";
                ViewData["MsgType"] = "warning";
                return View("EmailSend");
            }

            else
            {

                string template = @"Hi {0},<br/><br/>
                               This is the Temperature Sensor Web,
                               We hereby informing you that there's a fire outbreak in your estate!
                               Please contract the fire department
                               <br/><br/>Administrator";

                string title = "Email Notification Warning";
                string message = String.Format(template, usr.FullName);
                string result;
                if (EmailUtl.SendEmail(usr.Email, title, message, out result))
                {
                    ViewData["Message"] = "Email Successfully sent";
                    ViewData["MsgType"] = "success";
                }
                else
                {
                    ViewData["Message"] = result;
                    ViewData["MsgType"] = "warning";
                }
                return View("EmailSend");
            }
        }
    }
}

