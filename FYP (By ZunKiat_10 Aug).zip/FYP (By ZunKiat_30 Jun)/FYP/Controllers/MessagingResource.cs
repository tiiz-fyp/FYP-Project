﻿using System;

namespace FYP.Controllers
{
    internal class MessagingResource
    {
        public MessagingResource()
        {
        }

        internal void Message(string v)
        {
            throw new NotImplementedException();
        }
    }
}