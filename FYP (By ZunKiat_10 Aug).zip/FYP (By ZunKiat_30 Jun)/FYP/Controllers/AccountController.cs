using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Data;
using System.Security.Claims;
using FYP.Models;
using Microsoft.AspNetCore.Authorization;
using System.Collections.Generic;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using System.IO;
using Microsoft.AspNetCore.Hosting;
using Microsoft.EntityFrameworkCore.Metadata.Internal;
using Microsoft.AspNetCore.Mvc.ViewComponents;
using Twilio.Rest.Trunking.V1;
using System.Linq;

namespace FYP.Controllers
{

    public class AccountController : Controller
    {
        private const string LOGIN_SQL =
            @"SELECT * FROM SysUser 
            WHERE UserId = '{0}'
              AND UserPw = HASHBYTES('SHA1', '{1}')";

        private const string LASTLOGIN_SQL =
            @"UPDATE SysUser SET LastLogin=GETDATE() WHERE UserId='{0}'";

        private const string ROLE_COL = "UserRole";
        private const string NAME_COL = "FullName";

        private const string REDIRECT_CNTR = "Account";
        private const string REDIRECT_ACTN = "Login";

        private const string LOGIN_VIEW = "UserLogin";

        [AllowAnonymous]
        public IActionResult Login(string returnUrl = null)
        {
            TempData["ReturnUrl"] = returnUrl;
            return View(LOGIN_VIEW);
        }

        [AllowAnonymous]
        [HttpPost]
        public IActionResult Login(UserLogin user)
        {
            if (!AuthenticateUser(user.UserID, user.Password, out ClaimsPrincipal principal))
            {
                ViewData["Message"] = "Incorrect User ID or Password";
                ViewData["MsgType"] = "warning";
                return View(LOGIN_VIEW);
            }
            else
            {
                HttpContext.SignInAsync(
                CookieAuthenticationDefaults.AuthenticationScheme,
                principal);


                if (TempData["returnUrl"] != null)
                {
                    string returnUrl = TempData["returnUrl"].ToString();
                    if (Url.IsLocalUrl(returnUrl))
                        return Redirect(returnUrl);
                }

                return RedirectToAction(REDIRECT_ACTN, REDIRECT_CNTR);
            }
        }
        [Authorize]
        public IActionResult Logoff(string returnUrl = null)
        {
            HttpContext.SignOutAsync(CookieAuthenticationDefaults.AuthenticationScheme);
            if (Url.IsLocalUrl(returnUrl))
                return Redirect(returnUrl);
            return RedirectToAction(REDIRECT_ACTN, REDIRECT_CNTR);
        }

        [AllowAnonymous]
        public IActionResult Forbidden()
        {
            return View();
        }


        [Authorize(Roles = "admin")]
        public IActionResult Users()
        {
            string userid = User.FindFirst(ClaimTypes.NameIdentifier).Value;
            List<SysUser> list = DBUtl.GetList<SysUser>("SELECT * FROM SysUser WHERE UserRole='member' ", userid);
            return View("Users", list);
        }

        public IActionResult ListGuest()
        {
            string userid = User.FindFirst(ClaimTypes.NameIdentifier).Value;
            List<SysUser> list = DBUtl.GetList<SysUser>("SELECT * FROM SysUser WHERE UserId = '{0}'", userid);
            return View("ListGuest", list);
        }

        [HttpGet]
        public IActionResult Edit(string id)
        {
            string select = "SELECT * FROM SysUser WHERE UserId = '{0}'";
            List<SysUser> list = DBUtl.GetList<SysUser>(select, id);
            if (list.Count == 1)
            {
                return View(list[0]);
            }
            else
            {
                TempData["Message"] = "User not found";
                TempData["MsgType"] = "warning";
                return RedirectToAction("Users");
            }
        }

        [HttpPost]
        [Authorize(Roles = "admin")]
        public IActionResult Edit(SysUser sysUser)
        {
            string update = @"UPDATE SysUser SET Email='{1}', Mobile= {2}, Address='{3}' WHERE UserId= '{0}'";
            int res = DBUtl.ExecSQL(update, sysUser.UserId, sysUser.Email, sysUser.Mobile, sysUser.Address);
            if (res == 1)
            {
                TempData["Message"] = "Registered Users Info Updated";
                TempData["MsgType"] = "success";
            }
            else
            {
                TempData["Message"] = DBUtl.DB_Message;
                TempData["MsgType"] = "danger";
            }
            // Call the action Users to show the result of the update
            return RedirectToAction("Users");
        }

   
        [Authorize(Roles = "admin")]
        public IActionResult Delete(string id)
        {
            string delete = "DELETE FROM SysUser WHERE UserId ='{0}'";
            int res = DBUtl.ExecSQL(delete, id);
            if (res == 1)
            {
                TempData["Message"] = "User Record Deleted";
                TempData["MsgType"] = "success";
            }
            else
            {
                TempData["Message"] = DBUtl.DB_Message;
                TempData["MsgType"] = "danger";
            }
            return RedirectToAction("ListGuest");

        }
        [AllowAnonymous]
        public IActionResult Register()
        {
            return View("UserRegister");
        }

        [AllowAnonymous]
        [HttpPost]
        public IActionResult Register(SysUser usr)
        {
            if (!ModelState.IsValid)
            {
                ViewData["Message"] = "Invalid Input";
                ViewData["MsgType"] = "warning";
                return View("UserRegister");
            }
            else
            {
                string insert =
               @"INSERT INTO SysUser(UserId, UserPw, FullName, Email, Mobile, Address, UserRole) VALUES
                 ('{0}', HASHBYTES('SHA1', '{1}'), '{2}', '{3}', '{4}', '{5}', 'member')";
                if (DBUtl.ExecSQL(insert, usr.UserId, usr.UserPw, usr.FullName, usr.Email, usr.Mobile, usr.Address) == 1)
                {
                    string template = @"Hi {0},<br/><br/>
                               Welcome to Temperature Sensor Web
                               Your userid is <b>{1}</b> and password is <b>{2}</b>.
                               <br/><br/> From Administrator";
                    string title = "Registration Successul - Welcome";
                    string message = String.Format(template, usr.FullName, usr.UserId, usr.UserPw);
                    string result;
                    if (EmailUtl.SendEmail(usr.Email, title, message, out result))
                    {
                        ViewData["Message"] = "User Successfully Registered";
                        ViewData["MsgType"] = "success";
                    }
                    else
                    {
                        ViewData["Message"] = result;
                        ViewData["MsgType"] = "warning";
                    }
                }
                else
                {
                    ViewData["Message"] = DBUtl.DB_Message;
                    ViewData["MsgType"] = "danger";
                }
                return View("UserRegister");
            }
        }

        [AllowAnonymous]
        public IActionResult VerifyUserID(string userId)
        {
            string select = $"SELECT * FROM SysUser WHERE Userid='{userId}'";
            if (DBUtl.GetTable(select).Rows.Count > 0)
            {
                return Json($"[{userId}] already in use");
            }
            return Json(true);
        }
        private bool AuthenticateUser(string uid, string pw, out ClaimsPrincipal principal)
        {
            principal = null;

            DataTable ds = DBUtl.GetTable(LOGIN_SQL, uid, pw);
            if (ds.Rows.Count == 1)
            {
                principal =
                   new ClaimsPrincipal(
                      new ClaimsIdentity(
                         new Claim[] {
                        new Claim(ClaimTypes.NameIdentifier, uid),
                        new Claim(ClaimTypes.Name, ds.Rows[0][NAME_COL].ToString()),
                        new Claim(ClaimTypes.Role, ds.Rows[0][ROLE_COL].ToString())
                         }, "Basic"
                      )
                   );
                return true;
            }
            return false;
        }

        [HttpGet]
        public IActionResult Details(string id)
        {
            string userid = User.FindFirst(ClaimTypes.NameIdentifier).Value;
            string select = String.Format(@"SELECT * FROM SysUser WHERE UserId = '{0}'", userid);
            List<SysUser> list = DBUtl.GetList<SysUser>(select, id);
            if (list.Count == 1)
            {
                return View(list[0]);

            }
            else
            {
                ViewData["Message"] = "Users Record cannot be found";
                ViewData["MsgType"] = "warning";
                return View("Details");
            }
        }
    }
}