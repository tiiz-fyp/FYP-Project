﻿using System.Configuration;
using Microsoft.AspNetCore.Mvc;

using Twilio;
using Twilio.Rest.Api.V2010.Account;
using Twilio.Types;

using Twilio.TwiML;
using System;
using System.Security.Claims;
using Microsoft.Data.SqlClient;
using System.Data;
using MongoDB.Driver.Core.Operations;

namespace FYP.Controllers
{
    public class SMSController : Controller
    {
        public IActionResult SendSMS()
        {

            var accountSid = ConfigurationManager.AppSettings["Processing sending"];
            var authToken = ConfigurationManager.AppSettings["76cb96a7ef7dc1bf49edb04f1122b90e"];
            TwilioClient.Init("AC17ba988ac92051f9053058e4bbdb44bf", "76cb96a7ef7dc1bf49edb04f1122b90e");

            var to = new PhoneNumber(ConfigurationManager.AppSettings["+1 571 393 2228"]);
            var from = new PhoneNumber("+1 571 393 2228");

            var i = "+65 9272 3754";
            string userid = User.FindFirst(ClaimTypes.NameIdentifier).Value;

            var message = MessageResource.Create(
                to: i,
                from: "+1 571 393 2228",
                body: "There a fire detected in your household! Please alert the fire department!");

            return Content(message.Sid);

        }     
    }
}