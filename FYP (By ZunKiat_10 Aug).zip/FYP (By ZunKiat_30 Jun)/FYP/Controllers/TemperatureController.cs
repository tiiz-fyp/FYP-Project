﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using FYP.Models;
using System.Security.Cryptography.X509Certificates;
using Twilio.Rest.Trunking.V1;
using Twilio;

namespace FYP.Controllers
{
    public class TemperatureController : Controller
    {
        //[AllowAnonymous] or [Authorise] to specify access control

        [Authorize(Roles ="member")]
        public IActionResult About()
        {
            return View();
        }

        [Authorize(Roles = "admin")]
        public IActionResult AdminAbout()
        {
            return View("UserLogin");
        }

        [Authorize(Roles = "admin, member")]
        public IActionResult ListGuest()
        {
            DataTable dt = DBUtl.GetTable(
                @"SELECT * FROM SysUser");
            return View(dt.Rows);
        }
        [Authorize(Roles = "admin")]
        public IActionResult DisplayTemperature()
        {
            DataTable dt = DBUtl.GetTable(
                @"SELECT * FROM Temperature");
            return View(dt.Rows);
        }

        [HttpPost]
        public IActionResult DisplayTemperature(Temperature newTemp)
        {
            if (!ModelState.IsValid)
            {
                ViewData["Temperature"] = ListGuest();
                ViewData["Message"] = "Invalid Input";
                ViewData["MsgType"] = "warning";
                return View("AddTemperature");
            }
            else
            {
                //Secure INSERT statement
                string insert =
                   @"INSERT INTO Temperature(TemperatureId, TemperatureNumber, Details, Gas, Fire) 
                 VALUES({0}, {1}, '{2}', '{3}, '{4}')";

                int result = DBUtl.ExecSQL(insert, newTemp.TemperatureId, newTemp.TemperatureNumber, newTemp.Details);

                if (result == 1)
                {
                    TempData["Message"] = "Temperature Created";
                    TempData["MsgType"] = "success";
                }
                else
                {
                    TempData["Message"] = DBUtl.DB_Message;
                    TempData["MsgType"] = "danger";
                }
                return RedirectToAction("ListGuest");
            }
        }

        [Authorize(Roles = "member")]
        [HttpGet]
        public IActionResult OwnTemperature()
        {
            string sql = "SELECT * FROM Temperature;";
            DataTable dt = DBUtl.GetTable(sql);
            return View(dt.Rows);
        }

        [HttpPost]
        public IActionResult OwnTemperature(Temperature ownTemp)
        {
            if (!ModelState.IsValid)
            {
                ViewData["Temperature"] = OwnTemperature();
                ViewData["Message"] = "Invalid Input";
                ViewData["MsgType"] = "warning";
                return View();
            }
            else
            {
                //Secure INSERT statement
                string select =
                   @"SELECT * FROM Temperature(TemperatureId, TemperatureNumber, Details, UserId) 
                 VALUES({0}, {1}, {2}, '{3}')";

                int result = DBUtl.ExecSQL(select,  ownTemp.TemperatureId, ownTemp.TemperatureNumber, ownTemp.Details, ownTemp.UserId);

                if (result == 1)
                {
                    TempData["Message"] = "Temperature Display";
                    TempData["MsgType"] = "success";
                }
                else
                {
                    TempData["Message"] = DBUtl.DB_Message;
                    TempData["MsgType"] = "danger";
                }
                return RedirectToAction("About");
            }

        }
    }
}