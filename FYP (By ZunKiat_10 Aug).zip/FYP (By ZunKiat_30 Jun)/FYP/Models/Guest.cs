﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace FYP.Models
{
   public class Guest
   {
      //Provide suitable validation attributes

      public int GuestId { get; set; }

      [Required(ErrorMessage = "Enter a Username")]
      [StringLength(20, ErrorMessage = "Maximum is 20 Characters")]
      public string UName { get; set; }

      [Required(ErrorMessage = "Enter the Email")]
      public string Email { get; set; }

      [Required(ErrorMessage = "Enter a password")]
      public string Passwd { get; set; }

      public int TemperatureId { get; set; }

      public int TempatureNumber { get; set; }
   }
}
