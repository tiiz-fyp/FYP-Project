﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;

namespace FYP.Models
{
    public class UserProfileEdit : Controller
    {
        [Required]
        [Display(Name = "Email")]
        [DataType(DataType.EmailAddress)]
        public string Email { get; set; }

        [Required]
        [RegularExpression(@"[89]\d{7}", ErrorMessage = "Invalid Mobile Number!")]
        public int Mobile { get; set; }

        [Required]
        public string Address { get; set; }
    }
}
