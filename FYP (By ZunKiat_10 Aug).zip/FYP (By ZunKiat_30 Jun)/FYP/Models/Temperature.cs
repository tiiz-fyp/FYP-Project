﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace FYP.Models
{
    public class Temperature
    {
            public int TemperatureId { get; set; }
            public double TemperatureNumber { get; set; }
            public string Details { get; set; }
            public int UserId { get; set; }
    }
}

